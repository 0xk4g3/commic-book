// Pre-written story prompts for all 6 values
// Each story has 4 panels set entirely ON UAE trains during winter
// Characters wear proper UAE traditional clothing

export const STORY_PROMPTS = {
    courage: [
        {
            id: 'courage-1',
            title: 'The First Journey Alone',
            titleAr: 'الرحلة الأولى وحيداً',
            characters: [
                {
                    name: 'Ahmed',
                    description: 'A brave 11-year-old Emirati boy with short black hair, brown eyes, wearing white kandura with red-checked ghutra headscarf, nervous but determined',
                },
                {
                    name: 'Elderly Lady',
                    description: 'A kind 70-year-old Emirati woman with gentle smile, wearing elegant black abaya with gold trim, encouraging presence',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, windows showing city views',
            panels: [
                {
                    number: 1,
                    scene: 'Ahmed boarding the train alone for the first time, looking nervous at the doors',
                    action: 'Wide shot of ornate oriental train interior with traditional Arabic design',
                    mood: 'Nervous uncertainty',
                    tradition: 'Public transport independence',
                },
                {
                    number: 2,
                    scene: 'Ahmed sitting down, hands trembling slightly as train starts moving',
                    action: 'Close-up showing inner courage',
                    mood: 'Facing fear',
                    tradition: 'Growing independence',
                },
                {
                    number: 3,
                    scene: 'Elderly lady offering Ahmed encouraging words and a warm smile',
                    action: 'Medium shot of kind interaction',
                    mood: 'Community support',
                    tradition: 'Elder kindness',
                },
                {
                    number: 4,
                    scene: 'Ahmed arriving at destination, smiling proudly as he exits with confidence',
                    action: 'Wide shot of successful arrival',
                    mood: 'Proud accomplishment',
                    tradition: 'Personal growth',
                },
            ],
        },
        {
            id: 'courage-2',
            title: 'Speaking Up',
            titleAr: 'التحدث بشجاعة',
            characters: [
                {
                    name: 'Fatima',
                    description: 'A courageous 13-year-old Emirati girl with long black hair under colorful shayla, wearing pink abaya with gold embroidery, determined eyes',
                },
                {
                    name: 'Lost Tourist',
                    description: 'A confused foreign visitor holding a map, wearing winter jacket, looking worried and lost',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, diverse passengers',
            panels: [
                {
                    number: 1,
                    scene: 'Fatima noticing a lost tourist looking confused at train map',
                    action: 'Medium shot showing observation',
                    mood: 'Noticing someone in need',
                    tradition: 'UAE hospitality awareness',
                },
                {
                    number: 2,
                    scene: 'Fatima hesitating, gathering courage to speak in English',
                    action: 'Close-up on internal decision',
                    mood: 'Overcoming shyness',
                    tradition: 'Helpful nature',
                },
                {
                    number: 3,
                    scene: 'Fatima approaching and offering help with a friendly smile',
                    action: 'Action shot of reaching out',
                    mood: 'Taking brave action',
                    tradition: 'Emirati hospitality',
                },
                {
                    number: 4,
                    scene: 'Tourist thanking Fatima gratefully, both smiling as train continues',
                    action: 'Wide shot of positive outcome',
                    mood: 'Pride in helping',
                    tradition: 'Cultural bridge-building',
                },
            ],
        },
        {
            id: 'courage-3',
            title: 'The New School Route',
            titleAr: 'طريق المدرسة الجديد',
            characters: [
                {
                    name: 'Khalid',
                    description: 'A determined 10-year-old Emirati boy with curly black hair, wearing white kandura with school bag, initially worried expression',
                },
                {
                    name: 'Classmate Rashid',
                    description: 'A friendly 10-year-old Emirati boy with neat hair, wearing white kandura, supportive and cheerful',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, school children environment',
            panels: [
                {
                    number: 1,
                    scene: 'Khalid worried about taking new train route to school alone',
                    action: 'Close-up showing concern',
                    mood: 'Anxious about change',
                    tradition: 'School independence',
                },
                {
                    number: 2,
                    scene: 'Khalid meeting classmate Rashid who takes same route',
                    action: 'Medium shot of discovery',
                    mood: 'Finding support',
                    tradition: 'Friendship formation',
                },
                {
                    number: 3,
                    scene: 'Both boys navigating train together, Khalid gaining confidence',
                    action: 'Action shot of journey',
                    mood: 'Growing courage',
                    tradition: 'Peer support',
                },
                {
                    number: 4,
                    scene: 'Boys arriving at school stop together, Khalid no longer afraid',
                    action: 'Wide shot of arrival',
                    mood: 'Triumph over fear',
                    tradition: 'School commute mastery',
                },
            ],
        },
    ],

    kindness: [
        {
            id: 'kindness-1',
            title: 'Sharing Warmth',
            titleAr: 'مشاركة الدفء',
            characters: [
                {
                    name: 'Mariam',
                    description: 'A kind 12-year-old Emirati girl with gentle eyes, wearing purple abaya with silver embroidery under warm shayla, caring expression',
                },
                {
                    name: 'Elderly Man',
                    description: 'A 75-year-old Emirati grandfather with white beard, wearing traditional bisht over kandura, looking cold',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, warm lighting',
            panels: [
                {
                    number: 1,
                    scene: 'Mariam noticing elderly man shivering slightly from winter cold',
                    action: 'Medium shot of observation',
                    mood: 'Compassionate awareness',
                    tradition: 'Respecting elders',
                },
                {
                    number: 2,
                    scene: 'Mariam offering her warm scarf to the elderly man with smile',
                    action: 'Close-up on kind gesture',
                    mood: 'Selfless giving',
                    tradition: 'Generosity',
                },
                {
                    number: 3,
                    scene: 'Elderly man accepting gratefully, both sharing warm conversation',
                    action: 'Medium dialogue shot',
                    mood: 'Warmth and connection',
                    tradition: 'Intergenerational respect',
                },
                {
                    number: 4,
                    scene: 'Other passengers smiling at the kindness, warm atmosphere filling train',
                    action: 'Wide shot of impact',
                    mood: 'Inspiring others',
                    tradition: 'Community values',
                },
            ],
        },
        {
            id: 'kindness-2',
            title: 'The Dropped Bag',
            titleAr: 'الحقيبة المسقطة',
            characters: [
                {
                    name: 'Yousef',
                    description: 'A helpful 14-year-old Emirati boy with kind smile, wearing white kandura with blue trim, alert and considerate',
                },
                {
                    name: 'Working Mother',
                    description: 'A busy Emirati mother in her 30s wearing modern abaya, carrying baby and shopping bags, looking stressed',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, comfortable seating',
            panels: [
                {
                    number: 1,
                    scene: 'Mother struggling with baby and bags as something drops',
                    action: 'Action shot of items falling',
                    mood: 'Stress and overwhelm',
                    tradition: 'Modern family life',
                },
                {
                    number: 2,
                    scene: 'Yousef quickly picking up dropped items and approaching her',
                    action: 'Dynamic helping action',
                    mood: 'Immediate response',
                    tradition: 'Helpful nature',
                },
                {
                    number: 3,
                    scene: 'Yousef helping organize bags and entertaining baby with smile',
                    action: 'Medium shot of assistance',
                    mood: 'Thoughtful service',
                    tradition: 'Supporting families',
                },
                {
                    number: 4,
                    scene: 'Mother thanking Yousef warmly as train continues smoothly',
                    action: 'Wide shot of gratitude',
                    mood: 'Mutual appreciation',
                    tradition: 'Community care',
                },
            ],
        },
        {
            id: 'kindness-3',
            title: 'New Friend Welcome',
            titleAr: 'ترحيب صديق جديد',
            characters: [
                {
                    name: 'Noora',
                    description: 'A welcoming 11-year-old Emirati girl with warm smile, wearing light blue abaya with delicate patterns, friendly demeanor',
                },
                {
                    name: 'New Student',
                    description: 'A shy 11-year-old international student with backpack, wearing school uniform, looking lonely and uncertain',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, winter morning, students commuting, bright interior',
            panels: [
                {
                    number: 1,
                    scene: 'Noora seeing new student sitting alone looking sad on train',
                    action: 'Medium shot of noticing',
                    mood: 'Empathetic awareness',
                    tradition: 'Inclusive hospitality',
                },
                {
                    number: 2,
                    scene: 'Noora sitting next to new student and introducing herself warmly',
                    action: 'Close-up on friendly approach',
                    mood: 'Welcoming gesture',
                    tradition: 'UAE hospitality',
                },
                {
                    number: 3,
                    scene: 'Both girls sharing snacks and laughing together',
                    action: 'Action shot of bonding',
                    mood: 'Friendship forming',
                    tradition: 'Food sharing',
                },
                {
                    number: 4,
                    scene: 'Girls walking off train together to school, new friendship formed',
                    action: 'Wide shot of connection',
                    mood: 'Joyful belonging',
                    tradition: 'Inclusive community',
                },
            ],
        },
    ],

    resilience: [
        {
            id: 'resilience-1',
            title: 'The Long Commute',
            titleAr: 'الرحلة الطويلة',
            characters: [
                {
                    name: 'Rashed',
                    description: 'A persistent 13-year-old Emirati boy with determined eyes, wearing white kandura, carrying homework, focused expression',
                },
                {
                    name: 'Student Sara',
                    description: 'A studious 13-year-old Emirati girl with neat appearance, wearing navy abaya, also doing homework',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, winter, students studying while traveling, comfortable environment',
            panels: [
                {
                    number: 1,
                    scene: 'Rashed struggling with difficult homework on long train ride',
                    action: 'Close-up on frustration',
                    mood: 'Challenge and difficulty',
                    tradition: 'Dedication to education',
                },
                {
                    number: 2,
                    scene: 'Rashed wanting to give up but deciding to keep trying',
                    action: 'Medium shot of perseverance',
                    mood: 'Internal strength',
                    tradition: 'Not giving up',
                },
                {
                    number: 3,
                    scene: 'Sara offering to study together and help each other',
                    action: 'Action shot of collaboration',
                    mood: 'Teamwork spirit',
                    tradition: 'Mutual support',
                },
                {
                    number: 4,
                    scene: 'Both finishing homework successfully, high-fiving as train arrives',
                    action: 'Wide shot of achievement',
                    mood: 'Success through persistence',
                    tradition: 'Educational dedication',
                },
            ],
        },
        {
            id: 'resilience-2',
            title: 'Wait for Connection',
            titleAr: 'انتظار الاتصال',
            characters: [
                {
                    name: 'Sultan',
                    description: 'A patient 12-year-old Emirati boy with calm demeanor, wearing white kandura with warm jacket, learning patience',
                },
                {
                    name: 'Train Staff',
                    description: 'A professional Emirati train conductor in uniform, helpful and understanding',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, winter, missed connection delay situation',
            panels: [
                {
                    number: 1,
                    scene: 'Sultan missing connecting train by seconds, visibly disappointed',
                    action: 'Action shot of doors closing',
                    mood: 'Frustration with setback',
                    tradition: 'Dealing with disappointment',
                },
                {
                    number: 2,
                    scene: 'Sultan checking schedule and realizing long wait ahead',
                    action: 'Close-up showing patience test',
                    mood: 'Accepting situation',
                    tradition: 'Building patience',
                },
                {
                    number: 3,
                    scene: 'Staff explaining and offering kind words of encouragement',
                    action: 'Medium dialogue shot',
                    mood: 'Finding perspective',
                    tradition: 'Professional courtesy',
                },
                {
                    number: 4,
                    scene: 'Sultan using wait time productively, boarding next train calmly',
                    action: 'Wide shot of resilience',
                    mood: 'Turning setback into lesson',
                    tradition: 'Resourcefulness',
                },
            ],
        },
        {
            id: 'resilience-3',
            title: 'Technical Delay',
            titleAr: 'التأخير التقني',
            characters: [
                {
                    name: 'Hessa',
                    description: 'An adaptable 14-year-old Emirati girl with strong character, wearing green abaya, staying positive',
                },
                {
                    name: 'Fellow Passenger',
                    description: 'An anxious Emirati teenager complaining about delay, wearing casual kandura',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, passengers waiting inside',
            panels: [
                {
                    number: 1,
                    scene: 'Train stopping unexpectedly, announcement of technical delay',
                    action: 'Wide shot of stopped train',
                    mood: 'Unexpected challenge',
                    tradition: 'Handling disruptions',
                },
                {
                    number: 2,
                    scene: 'Hessa staying calm while others get frustrated',
                    action: 'Close-up on composed response',
                    mood: 'Maintaining composure',
                    tradition: 'Inner strength',
                },
                {
                    number: 3,
                    scene: 'Hessa helping calm anxious passenger with positive attitude',
                    action: 'Medium shot of influence',
                    mood: 'Leadership through challenge',
                    tradition: 'Positive influence',
                },
                {
                    number: 4,
                    scene: 'Train resuming, Hessa arriving late but unbothered, smiling',
                    action: 'Wide shot of arrival',
                    mood: 'Grace under pressure',
                    tradition: 'Adaptability',
                },
            ],
        },
    ],

    respect: [
        {
            id: 'respect-1',
            title: 'Priority Seating',
            titleAr: 'مقاعد الأولوية',
            characters: [
                {
                    name: 'Abdullah',
                    description: 'A respectful 10-year-old Emirati boy with polite manners, wearing white kandura with respectful posture',
                },
                {
                    name: 'Pregnant Lady',
                    description: 'An Emirati woman in late pregnancy, wearing comfortable abaya, looking tired',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, winter rush hour, limited seating, busy commute time',
            panels: [
                {
                    number: 1,
                    scene: 'Abdullah sitting in regular seat as pregnant lady boards crowded train',
                    action: 'Wide shot of crowded train',
                    mood: 'Awareness of situation',
                    tradition: 'Public transport etiquette',
                },
                {
                    number: 2,
                    scene: 'Abdullah immediately standing and offering his seat politely',
                    action: 'Action shot of respectful gesture',
                    mood: 'Automatic courtesy',
                    tradition: 'Respecting women and elders',
                },
                {
                    number: 3,
                    scene: 'Lady thanking Abdullah warmly as she sits gratefully',
                    action: 'Close-up on exchange',
                    mood: 'Mutual respect',
                    tradition: 'Proper manners',
                },
                {
                    number: 4,
                    scene: 'Other passengers noticing and smiling approvingly at good behavior',
                    action: 'Wide shot of positive example',
                    mood: 'Inspiring respect',
                    tradition: 'Community values',
                },
            ],
        },
        {
            id: 'respect-2',
            title: 'Quiet Zone Honor',
            titleAr: 'احترام المنطقة الهادئة',
            characters: [
                {
                    name: 'Latifa',
                    description: 'A considerate 13-year-old Emirati girl with mindful nature, wearing elegant blue abaya, aware of surroundings',
                },
                {
                    name: 'Studying Student',
                    description: 'An Emirati university student with books and headphones, needing concentration',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, winter, designated peaceful area, study-friendly environment',
            panels: [
                {
                    number: 1,
                    scene: 'Latifa entering quiet zone with friends who are being loud',
                    action: 'Medium shot of entry',
                    mood: 'Noticing disruption',
                    tradition: 'Respecting space rules',
                },
                {
                    number: 2,
                    scene: 'Latifa seeing student trying to study, being disturbed',
                    action: 'Close-up on consideration',
                    mood: 'Empathetic awareness',
                    tradition: 'Consideration for others',
                },
                {
                    number: 3,
                    scene: 'Latifa politely asking friends to lower voices or move',
                    action: 'Action shot of leadership',
                    mood: 'Respectful correction',
                    tradition: 'Social responsibility',
                },
                {
                    number: 4,
                    scene: 'Everyone quietly respecting space, student nodding thanks to Latifa',
                    action: 'Wide shot of harmony',
                    mood: 'Peaceful coexistence',
                    tradition: 'Public courtesy',
                },
            ],
        },
        {
            id: 'respect-3',
            title: 'Cultural Understanding',
            titleAr: 'الفهم الثقافي',
            characters: [
                {
                    name: 'Mohammed',
                    description: 'An understanding 15-year-old Emirati boy with open mind, wearing white kandura, culturally aware',
                },
                {
                    name: 'Foreign Visitor',
                    description: 'A respectful tourist unfamiliar with local customs, wanting to learn',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, cultural exchange environment',
            panels: [
                {
                    number: 1,
                    scene: 'Tourist uncertain about train customs, looking confused',
                    action: 'Medium shot of uncertainty',
                    mood: 'Cultural curiosity',
                    tradition: 'Cross-cultural awareness',
                },
                {
                    number: 2,
                    scene: 'Mohammed respectfully explaining local etiquette with patience',
                    action: 'Close-up on teaching',
                    mood: 'Gentle guidance',
                    tradition: 'Cultural ambassador',
                },
                {
                    number: 3,
                    scene: 'Tourist learning and appreciating Emirati culture respectfully',
                    action: 'Action shot of exchange',
                    mood: 'Mutual respect',
                    tradition: 'Cultural bridge',
                },
                {
                    number: 4,
                    scene: 'Both sharing positive interaction, understanding achieved',
                    action: 'Wide shot of connection',
                    mood: 'Cultural harmony',
                    tradition: 'UAE hospitality',
                },
            ],
        },
    ],

    tolerance: [
        {
            id: 'tolerance-1',
            title: 'Many Languages',
            titleAr: 'لغات كثيرة',
            characters: [
                {
                    name: 'Saif',
                    description: 'An open-minded 12-year-old Emirati boy with friendly smile, wearing white kandura with colored trim, curious about diversity',
                },
                {
                    name: 'International Group',
                    description: 'Diverse group of students from different countries, various cultural dress, friendly atmosphere',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, winter, multicultural environment, students from international schools',
            panels: [
                {
                    number: 1,
                    scene: 'Saif hearing multiple languages being spoken on train',
                    action: 'Wide shot of diverse passengers',
                    mood: 'Curious fascination',
                    tradition: 'UAE diversity',
                },
                {
                    number: 2,
                    scene: 'Saif joining conversation, learning greetings in different languages',
                    action: 'Medium shot of exchange',
                    mood: 'Enthusiastic learning',
                    tradition: 'Cultural openness',
                },
                {
                    number: 3,
                    scene: 'Everyone teaching each other words from their languages',
                    action: 'Action shot of sharing',
                    mood: 'Joyful diversity',
                    tradition: 'Language appreciation',
                },
                {
                    number: 4,
                    scene: 'Group laughing together, unified despite differences',
                    action: 'Wide shot of unity',
                    mood: 'Celebrating diversity',
                    tradition: 'UAE multiculturalism',
                },
            ],
        },
        {
            id: 'tolerance-2',
            title: 'Different Celebrations',
            titleAr: 'احتفالات مختلفة',
            characters: [
                {
                    name: 'Aisha',
                    description: 'A curious 11-year-old Emirati girl with interest in cultures, wearing pink abaya with elegant design, open-minded',
                },
                {
                    name: 'Classmate Priya',
                    description: 'An Indian girl in her 11-year-old wearing colorful traditional dress for Diwali, excited and friendly',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, winter holiday season, festive decorations, families traveling',
            panels: [
                {
                    number: 1,
                    scene: 'Aisha noticing Priya in traditional dress for different cultural celebration',
                    action: 'Medium shot of observation',
                    mood: 'Interested curiosity',
                    tradition: 'Cultural awareness',
                },
                {
                    number: 2,
                    scene: 'Aisha asking respectfully about Priya\'s celebration and dress',
                    action: 'Close-up on respectful inquiry',
                    mood: 'Genuine interest',
                    tradition: 'Learning about others',
                },
                {
                    number: 3,
                    scene: 'Priya sharing her culture, Aisha sharing about Emirati celebrations',
                    action: 'Action shot of cultural exchange',
                    mood: 'Mutual appreciation',
                    tradition: 'Cultural sharing',
                },
                {
                    number: 4,
                    scene: 'Both girls appreciating each other\'s traditions, smiling warmly',
                    action: 'Wide shot of friendship',
                    mood: 'Unified in diversity',
                    tradition: 'Tolerance and acceptance',
                },
            ],
        },
        {
            id: 'tolerance-3',
            title: 'Different Abilities',
            titleAr: 'قدرات مختلفة',
            characters: [
                {
                    name: 'Hamad',
                    description: 'An empathetic 14-year-old Emirati boy with understanding nature, wearing white kandura, compassionate eyes',
                },
                {
                    name: 'Student with Wheelchair',
                    description: 'A determined student using wheelchair, carrying school books, independent spirit',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, winter, ramp and designated areas, inclusive design',
            panels: [
                {
                    number: 1,
                    scene: 'Hamad noticing student in wheelchair needing assistance on train',
                    action: 'Medium shot of awareness',
                    mood: 'Empathetic noticing',
                    tradition: 'Helping community',
                },
                {
                    number: 2,
                    scene: 'Hamad respectfully asking if help is needed, not assuming',
                    action: 'Close-up on respectful approach',
                    mood: 'Dignified assistance',
                    tradition: 'Respectful inclusion',
                },
                {
                    number: 3,
                    scene: 'Both talking as equals, finding common interests',
                    action: 'Action shot of conversation',
                    mood: 'Seeing person, not disability',
                    tradition: 'Equality and respect',
                },
                {
                    number: 4,
                    scene: 'Forming friendship based on mutual respect and understanding',
                    action: 'Wide shot of connection',
                    mood: 'Inclusive friendship',
                    tradition: 'Human dignity',
                },
            ],
        },
    ],

    creativity: [
        {
            id: 'creativity-1',
            title: 'Train Story Telling',
            titleAr: 'سرد قصص القطار',
            characters: [
                {
                    name: 'Zayed',
                    description: 'A creative 13-year-old Emirati boy with vivid imagination, wearing white kandura, animated storyteller',
                },
                {
                    name: 'Younger Children',
                    description: 'Group of 3 young Emirati children aged 6-8, wearing traditional dress, captivated listeners',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, journey entertainment',
            panels: [
                {
                    number: 1,
                    scene: 'Young children bored on long train ride, restless and fidgety',
                    action: 'Wide shot of restless scene',
                    mood: 'Boredom and energy',
                    tradition: 'Family travel',
                },
                {
                    number: 2,
                    scene: 'Zayed getting creative idea to tell traditional stories with modern twist',
                    action: 'Close-up on inspiration',
                    mood: 'Creative spark',
                    tradition: 'Storytelling heritage',
                },
                {
                    number: 3,
                    scene: 'Zayed animatedly telling exciting story, children mesmerized',
                    action: 'Action shot of storytelling',
                    mood: 'Imaginative engagement',
                    tradition: 'Oral tradition',
                },
                {
                    number: 4,
                    scene: 'All children happily entertained, time flying by on journey',
                    action: 'Wide shot of success',
                    mood: 'Joy through creativity',
                    tradition: 'Cultural entertainment',
                },
            ],
        },
        {
            id: 'creativity-2',
            title: 'Window Art Ideas',
            titleAr: 'أفكار فنية من النافذة',
            characters: [
                {
                    name: 'Moza',
                    description: 'An artistic 12-year-old Emirati girl with sketchbook, wearing teal abaya, observant artist eyes',
                },
                {
                    name: 'Art Teacher',
                    description: 'An encouraging Emirati art teacher in her 30s, wearing professional abaya, supportive mentor',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, winter, scenic route with city and desert views, natural inspiration',
            panels: [
                {
                    number: 1,
                    scene: 'Moza staring out train window at changing landscapes',
                    action: 'Medium shot through window',
                    mood: 'Observant inspiration',
                    tradition: 'UAE landscape appreciation',
                },
                {
                    number: 2,
                    scene: 'Moza sketching creative interpretations of what she sees',
                    action: 'Close-up on artistic creation',
                    mood: 'Creative flow',
                    tradition: 'Artistic expression',
                },
                {
                    number: 3,
                    scene: 'Teacher noticing and encouraging Moza\'s unique artistic vision',
                    action: 'Action shot of mentorship',
                    mood: 'Validated creativity',
                    tradition: 'Supporting talent',
                },
                {
                    number: 4,
                    scene: 'Moza sharing sketches, inspiring other passengers with her art',
                    action: 'Wide shot of sharing',
                    mood: 'Creative inspiration spreading',
                    tradition: 'Artistic community',
                },
            ],
        },
        {
            id: 'creativity-3',
            title: 'Musical Connections',
            titleAr: 'اتصالات موسيقية',
            characters: [
                {
                    name: 'Rashid',
                    description: 'A musical 15-year-old Emirati boy with headphones, wearing white kandura, rhythm in his soul',
                },
                {
                    name: 'Street Musician',
                    description: 'A talented busker with traditional and modern instruments, multicultural appearance',
                },
            ],
            setting: 'Oriental luxury train with ornate Arabic interior design, featuring traditional arabesque patterns, carved wood panels, brass fixtures, rich velvet fabrics in deep jewel tones, and geometric Islamic art motifs during cool UAE winter, cultural sounds',
            panels: [
                {
                    number: 1,
                    scene: 'Rashid hearing beautiful music at train station before boarding',
                    action: 'Wide shot of station performance',
                    mood: 'Musical discovery',
                    tradition: 'Appreciation of arts',
                },
                {
                    number: 2,
                    scene: 'Rashid imagining fusion of traditional Emirati and modern music',
                    action: 'Close-up on creative vision',
                    mood: 'Innovative thinking',
                    tradition: 'Musical creativity',
                },
                {
                    number: 3,
                    scene: 'Rashid discussing ideas with musician, both excited about possibilities',
                    action: 'Action shot of collaboration',
                    mood: 'Creative partnership',
                    tradition: 'Cultural fusion',
                },
                {
                    number: 4,
                    scene: 'Rashid on train, writing musical ideas, inspired by experience',
                    action: 'Wide shot of creative work',
                    mood: 'Inspired creation',
                    tradition: 'Modern Emirati artistry',
                },
            ],
        },
    ],
};
